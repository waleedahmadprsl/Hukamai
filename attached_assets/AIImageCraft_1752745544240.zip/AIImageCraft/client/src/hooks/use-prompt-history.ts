import { useState, useEffect } from "react";

interface PromptHistoryItem {
  prompt: string;
  timestamp: Date;
}

export function usePromptHistory() {
  const [history, setHistory] = useState<PromptHistoryItem[]>([]);

  useEffect(() => {
    // Load history from localStorage
    const savedHistory = localStorage.getItem("hukam-prompt-history");
    if (savedHistory) {
      try {
        const parsed = JSON.parse(savedHistory);
        const withDates = parsed.map((item: any) => ({
          ...item,
          timestamp: new Date(item.timestamp),
        }));
        setHistory(withDates);
      } catch (error) {
        console.error("Failed to parse prompt history:", error);
      }
    }
  }, []);

  const saveHistory = (newHistory: PromptHistoryItem[]) => {
    setHistory(newHistory);
    localStorage.setItem("hukam-prompt-history", JSON.stringify(newHistory));
  };

  const addPrompt = (prompt: string) => {
    const newItem: PromptHistoryItem = {
      prompt,
      timestamp: new Date(),
    };
    
    // Add to beginning and keep only last 100
    const newHistory = [newItem, ...history.filter(item => item.prompt !== prompt)].slice(0, 100);
    saveHistory(newHistory);
  };

  const removePrompt = (index: number) => {
    const newHistory = history.filter((_, i) => i !== index);
    saveHistory(newHistory);
  };

  const clearHistory = () => {
    saveHistory([]);
  };

  return {
    history,
    addPrompt,
    removePrompt,
    clearHistory,
  };
}
