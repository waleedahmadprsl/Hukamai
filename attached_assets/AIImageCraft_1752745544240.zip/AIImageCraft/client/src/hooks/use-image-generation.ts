import { useState, useCallback } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface GeneratedImage {
  url: string;
  prompt: string;
  usedApiKey: string;
}

interface GenerationProgress {
  current: number;
  total: number;
}

export function useImageGeneration() {
  const [progress, setProgress] = useState<GenerationProgress>({ current: 0, total: 0 });
  const [statusText, setStatusText] = useState("Ready to generate...");
  const [countdown, setCountdown] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  const [shouldStop, setShouldStop] = useState(false);
  const [currentImageUrl, setCurrentImageUrl] = useState<string | null>(null);
  const { toast } = useToast();

  // Fetch images from database
  const { data: images = [], refetch: refetchImages } = useQuery({
    queryKey: ['/api/images'],
    refetchInterval: isGenerating ? 2000 : false, // Refetch every 2 seconds while generating
  });

  const generateMutation = useMutation({
    mutationFn: async ({ prompt, n, customApiKey }: { prompt: string; n: number; customApiKey?: string }) => {
      const response = await apiRequest('POST', '/api/generate-image', {
        prompt,
        n,
        customApiKey,
      });
      return response.json();
    },
  });

  const generateImages = useCallback(async (prompts: string[], imagesPerPrompt: number) => {
    const customApiKey = localStorage.getItem("hukam-custom-api-key");
    const totalRequests = prompts.length * imagesPerPrompt;
    let currentRequest = 0;
    let failedRequests = 0;
    
    setIsGenerating(true);
    setShouldStop(false);
    setProgress({ current: 0, total: totalRequests });
    setStatusText("Starting generation...");
    setCurrentImageUrl(null);
    setCountdown(0);
    
    for (let promptIndex = 0; promptIndex < prompts.length; promptIndex++) {
      if (shouldStop) {
        setStatusText("Generation stopped by user.");
        break;
      }
      
      const prompt = prompts[promptIndex];
      
      // Generate images one by one for this prompt
      for (let imageIndex = 0; imageIndex < imagesPerPrompt; imageIndex++) {
        if (shouldStop) {
          setStatusText("Generation stopped by user.");
          break;
        }
        
        currentRequest++;
        setProgress({ current: currentRequest, total: totalRequests });
        setStatusText(`Generating image ${imageIndex + 1} of ${imagesPerPrompt} for prompt ${promptIndex + 1}...`);
        setCurrentImageUrl(null);
        
        try {
          const result = await generateMutation.mutateAsync({
            prompt,
            n: 1, // Always generate 1 image at a time
            customApiKey: customApiKey || undefined,
          });
          
          // Add generated image to the list
          const newImage = {
            ...result.images[0],
            usedApiKey: result.usedApiKey,
          };
          
          setCurrentImageUrl(newImage.url);
          // Refetch images to update the list
          refetchImages();
          
          // Success feedback
          toast({
            title: "Image generated",
            description: `Generated image ${imageIndex + 1} for: ${prompt.substring(0, 50)}${prompt.length > 50 ? '...' : ''}`,
          });
          
        } catch (error: any) {
          failedRequests++;
          console.error('Generation error:', error);
          
          // Check if it's a rate limit error
          if (error.message.includes('Rate limit')) {
            setStatusText("Rate limited. Waiting 60 seconds to retry...");
            
            // 60 second countdown
            for (let i = 60; i > 0; i--) {
              if (shouldStop) break;
              setCountdown(i);
              await new Promise(resolve => setTimeout(resolve, 1000));
            }
            setCountdown(0);
            
            // Retry the same image
            if (!shouldStop) {
              currentRequest--; // Reset counter for retry
              imageIndex--; // Retry this image
              continue;
            }
          } else {
            toast({
              title: "Generation failed",
              description: error.message || "Failed to generate image",
              variant: "destructive",
            });
          }
          
          // If too many requests fail, show warning
          if (failedRequests >= 3) {
            toast({
              title: "Server busy",
              description: "⚠️ Server busy. Try again later.",
              variant: "destructive",
            });
            setIsGenerating(false);
            return;
          }
        }
        
        // Wait 20 seconds between individual image generations (except for the last one)
        if (currentRequest < totalRequests && !shouldStop) {
          setStatusText(`Waiting 20 seconds before next image...`);
          for (let i = 20; i > 0; i--) {
            if (shouldStop) break;
            setCountdown(i);
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
          setCountdown(0);
          setCurrentImageUrl(null); // Clear preview before next image
        }
      }
    }
    
    setIsGenerating(false);
    setCurrentImageUrl(null);
    if (!shouldStop) {
      setStatusText(`Generation complete!`);
      setProgress({ current: totalRequests, total: totalRequests });
    }
  }, [generateMutation, refetchImages, toast, shouldStop]);

  const downloadImage = useCallback(async (image: GeneratedImage) => {
    try {
      const response = await fetch(`/api/proxy-image?url=${encodeURIComponent(image.imageUrl)}`);
      const blob = await response.blob();
      
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${image.prompt.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50)}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Download started",
        description: "Image download has started",
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Failed to download image",
        variant: "destructive",
      });
    }
  }, [toast]);

  const stopGeneration = useCallback(() => {
    setShouldStop(true);
    setStatusText("Stopping generation...");
    setCurrentImageUrl(null);
    setCountdown(0);
  }, []);

  return {
    images,
    isGenerating,
    progress,
    statusText,
    countdown,
    currentImageUrl,
    generateImages,
    downloadImage,
    stopGeneration,
  };
}
