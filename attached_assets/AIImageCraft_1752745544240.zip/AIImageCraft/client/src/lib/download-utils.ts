import JSZip from "jszip";
import { saveAs } from "file-saver";

interface GeneratedImage {
  imageUrl: string;
  prompt: string;
  usedApiKey: string;
}

export async function downloadAllAsZip(images: GeneratedImage[]) {
  const zip = new JSZip();
  
  // Keep track of filenames to avoid duplicates
  const usedFilenames = new Set<string>();
  
  for (let i = 0; i < images.length; i++) {
    const image = images[i];
    
    try {
      // Fetch image via proxy
      const response = await fetch(`/api/proxy-image?url=${encodeURIComponent(image.imageUrl)}`);
      if (!response.ok) {
        console.error(`Failed to fetch image ${i + 1}:`, response.statusText);
        continue;
      }
      
      const blob = await response.blob();
      
      // Create filename from prompt
      let baseFilename = image.prompt
        .replace(/[^a-zA-Z0-9\s]/g, '') // Remove special characters
        .replace(/\s+/g, '_') // Replace spaces with underscores
        .substring(0, 50) // Limit length
        .toLowerCase();
      
      // Ensure unique filename
      let filename = `${baseFilename}.png`;
      let counter = 1;
      while (usedFilenames.has(filename)) {
        filename = `${baseFilename}_${counter}.png`;
        counter++;
      }
      usedFilenames.add(filename);
      
      // Add to zip
      zip.file(filename, blob);
      
    } catch (error) {
      console.error(`Failed to process image ${i + 1}:`, error);
    }
  }
  
  // Generate and download zip
  const content = await zip.generateAsync({ type: "blob" });
  const timestamp = new Date().toISOString().substring(0, 10);
  saveAs(content, `hukam_images_${timestamp}.zip`);
}
