import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useImageGeneration } from "@/hooks/use-image-generation";
import { usePromptHistory } from "@/hooks/use-prompt-history";
import { downloadAllAsZip } from "@/lib/download-utils";
import { useToast } from "@/hooks/use-toast";

const promptTemplates = [
  "A [adjective] [animal] in [style] style",
  "A beautiful [setting] with [object]",
  "Digital art of [subject] in [mood] lighting",
  "A [color] [landscape] with [weather] conditions",
  "Portrait of a [character] in [time period] style",
];

const surpriseMePrompts = [
  "A serene mountain landscape at sunset with purple and orange hues",
  "A futuristic city skyline with neon lights and flying vehicles",
  "A magical forest scene with glowing mushrooms and fairy lights",
  "A cozy cabin by a frozen lake with northern lights",
  "A steampunk robot playing violin in a Victorian ballroom",
  "A crystal cave with bioluminescent plants and waterfalls",
  "A floating island with cherry blossoms and ancient temples",
  "A cyberpunk street market with holographic advertisements",
];

export function ImageGenerator() {
  const [promptText, setPromptText] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [imagesPerPrompt, setImagesPerPrompt] = useState("1");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropZoneRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { addPrompt } = usePromptHistory();
  const {
    images,
    isGenerating,
    progress,
    statusText,
    countdown,
    currentImageUrl,
    generateImages,
    downloadImage,
    stopGeneration,
  } = useImageGeneration();

  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setPromptText(content);
    };
    reader.readAsText(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    dropZoneRef.current?.classList.add("drag-over");
  };

  const handleDragLeave = () => {
    dropZoneRef.current?.classList.remove("drag-over");
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    dropZoneRef.current?.classList.remove("drag-over");
    const files = e.dataTransfer.files;
    if (files.length > 0 && files[0].type === "text/plain") {
      handleFileUpload(files[0]);
    }
  };

  const handleSurpriseMe = () => {
    const randomPrompt = surpriseMePrompts[Math.floor(Math.random() * surpriseMePrompts.length)];
    setPromptText(randomPrompt);
  };

  const handleGenerate = async () => {
    if (!promptText.trim()) {
      toast({
        title: "Error",
        description: "Please enter at least one prompt",
        variant: "destructive",
      });
      return;
    }

    const prompts = promptText.split('\n').filter(p => p.trim());
    const n = parseInt(imagesPerPrompt);
    
    // Add to history
    prompts.forEach(prompt => addPrompt(prompt.trim()));
    
    await generateImages(prompts, n);
  };

  const handleDownloadAll = async () => {
    if (images.length === 0) {
      toast({
        title: "No images",
        description: "Generate some images first before downloading",
        variant: "destructive",
      });
      return;
    }

    try {
      await downloadAllAsZip(images);
      toast({
        title: "Download started",
        description: "Your images are being downloaded as a ZIP file",
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Failed to download images. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Left Sidebar - Controls */}
      <div className="lg:col-span-1 space-y-6">
        {/* Prompt Input */}
        <Card className="glass-morphism rounded-2xl shadow-xl border-white/20">
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Generate Images</h2>
            
            {/* Prompt Templates */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-white/80 mb-2">Prompt Templates</label>
              <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                <SelectTrigger className="w-full bg-white/10 border-white/20 text-white">
                  <SelectValue placeholder="Select a template..." />
                </SelectTrigger>
                <SelectContent>
                  {promptTemplates.map((template, index) => (
                    <SelectItem key={index} value={template}>{template}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {/* File Drop Zone */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-white/80 mb-2">Prompts (one per line)</label>
              <div 
                ref={dropZoneRef}
                className="drop-zone rounded-lg p-4 mb-3 cursor-pointer"
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
              >
                <div className="text-center">
                  <i className="fas fa-cloud-upload-alt text-4xl text-white/50 mb-2"></i>
                  <p className="text-white/70">Drop .txt file here or click to browse</p>
                </div>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept=".txt"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
              />
              <Textarea
                className="w-full h-32 bg-white/10 border-white/20 text-white placeholder-white/50 focus:border-indigo-400 resize-none"
                placeholder="Enter your prompts here, one per line...&#10;Example:&#10;A serene mountain landscape&#10;A futuristic city skyline&#10;A magical forest scene"
                value={promptText}
                onChange={(e) => setPromptText(e.target.value)}
              />
              {promptText.trim() && (
                <div className="mt-2 text-xs text-white/60">
                  <i className="fas fa-list-ul mr-1"></i>
                  {promptText.split('\n').filter(p => p.trim()).length} prompt{promptText.split('\n').filter(p => p.trim()).length !== 1 ? 's' : ''} detected
                  {parseInt(imagesPerPrompt) > 1 && (
                    <span className="ml-2 text-indigo-300">
                      ({promptText.split('\n').filter(p => p.trim()).length * parseInt(imagesPerPrompt)} total images)
                    </span>
                  )}
                </div>
              )}
            </div>
            
            {/* Controls */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">Images per prompt</label>
                <Select value={imagesPerPrompt} onValueChange={setImagesPerPrompt}>
                  <SelectTrigger className="w-full bg-white/10 border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => (
                      <SelectItem key={n} value={n.toString()}>{n} image{n > 1 ? 's' : ''}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex space-x-3">
                <Button
                  className="flex-1 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-medium hover-glow"
                  onClick={handleSurpriseMe}
                  disabled={isGenerating}
                >
                  <i className="fas fa-dice mr-2"></i>
                  Surprise Me
                </Button>
                {!isGenerating ? (
                  <Button
                    className="flex-1 bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white font-medium hover-glow"
                    onClick={handleGenerate}
                  >
                    <i className="fas fa-magic mr-2"></i>
                    Generate
                  </Button>
                ) : (
                  <Button
                    className="flex-1 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-medium hover-glow"
                    onClick={stopGeneration}
                  >
                    <i className="fas fa-stop mr-2"></i>
                    Stop
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Progress Panel */}
        {isGenerating && (
          <Card className="glass-morphism rounded-2xl shadow-xl border-white/20">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Generation Progress</h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm text-white/80">
                  <span>Progress</span>
                  <span>{progress.current} / {progress.total}</span>
                </div>
                <Progress value={(progress.current / progress.total) * 100} className="w-full" />
                <div className="text-sm text-white/70">{statusText}</div>
                {countdown > 0 && (
                  <div className="text-xs text-white/50">Next image in: {countdown}s</div>
                )}
                {isGenerating && (
                  <div className="mt-4">
                    <div className="text-xs text-white/50 mb-2">
                      {currentImageUrl ? "Latest generated image:" : "Generating image..."}
                    </div>
                    <div className="relative w-full h-32 bg-black/20 rounded-lg overflow-hidden generating-preview">
                      {currentImageUrl ? (
                        <img 
                          src={`/api/proxy-image?url=${encodeURIComponent(currentImageUrl)}`} 
                          alt="Latest generated"
                          className="w-full h-full object-cover opacity-80"
                          onLoad={() => console.log("Image loaded successfully:", currentImageUrl)}
                          onError={(e) => console.error("Image failed to load:", currentImageUrl, e)}
                        />
                      ) : (
                        <div className="w-full h-full loading-shimmer flex items-center justify-center">
                          <div className="text-white/50 text-center">
                            <i className="fas fa-magic text-2xl mb-2"></i>
                            <div className="text-xs">Creating image...</div>
                          </div>
                        </div>
                      )}
                      {!currentImageUrl && (
                        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/20 to-purple-500/20 animate-pulse"></div>
                      )}
                      <div className="absolute bottom-2 left-2 text-xs text-white/70">
                        <i className="fas fa-spinner fa-spin mr-1"></i>
                        {currentImageUrl ? "Ready" : "Processing..."}
                      </div>
                    </div>
                    <div className="text-xs text-white/30 mt-1">
                      Debug: {currentImageUrl ? `URL: ${currentImageUrl.substring(0, 50)}...` : "No URL"}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Download Panel */}
        <Card className="glass-morphism rounded-2xl shadow-xl border-white/20">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Download Options</h3>
            <div className="space-y-3">
              <Button
                className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-medium hover-glow"
                onClick={handleDownloadAll}
              >
                <i className="fas fa-download mr-2"></i>
                Download All (ZIP)
              </Button>
              <div className="text-xs text-white/50 text-center">
                {images.length} images ready for download
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Main Content Area */}
      <div className="lg:col-span-2">
        {/* View Toggle */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Generated Images</h2>
          <div className="flex items-center space-x-4">
            <div className="glass-morphism rounded-lg p-1 flex">
              <Button
                variant="ghost"
                size="sm"
                className={`p-2 text-white hover:bg-white/20 ${viewMode === 'grid' ? 'bg-white/20' : ''}`}
                onClick={() => setViewMode('grid')}
              >
                <i className="fas fa-th"></i>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className={`p-2 text-white hover:bg-white/20 ${viewMode === 'list' ? 'bg-white/20' : ''}`}
                onClick={() => setViewMode('list')}
              >
                <i className="fas fa-list"></i>
              </Button>
            </div>
          </div>
        </div>
        
        {/* Images Grid */}
        {images.length > 0 ? (
          <div className={viewMode === 'grid' ? 'image-grid' : 'space-y-4'}>
            {images.map((image, index) => (
              <Card key={index} className="glass-morphism rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 border-white/20">
                <CardContent className="p-4">
                  <img 
                    src={`/api/proxy-image?url=${encodeURIComponent(image.imageUrl)}`} 
                    alt={image.prompt}
                    className="w-full h-64 object-cover rounded-xl mb-3"
                  />
                  <div className="space-y-3">
                    <div className="text-sm text-white/70 leading-relaxed">
                      <strong>Prompt:</strong> {image.prompt}
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-white/50">{image.usedApiKey}</span>
                        <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      </div>
                      <Button
                        className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white text-sm font-medium"
                        onClick={() => downloadImage(image)}
                      >
                        <i className="fas fa-download mr-1"></i>
                        Download
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Card className="glass-morphism rounded-2xl p-8 max-w-md mx-auto border-white/20">
              <CardContent className="p-0">
                <i className="fas fa-image text-6xl text-white/30 mb-4"></i>
                <h3 className="text-xl font-semibold text-white mb-2">No images generated yet</h3>
                <p className="text-white/70 mb-6">Enter some prompts and click generate to get started!</p>
                <Button 
                  className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-medium hover-glow"
                  onClick={handleGenerate}
                  disabled={!promptText.trim()}
                >
                  <i className="fas fa-magic mr-2"></i>
                  Generate Images
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
