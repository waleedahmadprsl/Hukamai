import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ApiStatusModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ApiStatusModal({ open, onOpenChange }: ApiStatusModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: apiStatus, isLoading } = useQuery({
    queryKey: ['/api/api-key-status'],
    enabled: open,
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const resetMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', '/api/reset-api-keys');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/api-key-status'] });
      toast({
        title: "API Keys Reset",
        description: "All API keys have been reset successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Reset Failed",
        description: error.message || "Failed to reset API keys",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-400';
      case 'cooldown':
        return 'bg-yellow-400';
      case 'rate_limited':
        return 'bg-red-400';
      default:
        return 'bg-gray-400';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active':
        return 'Active';
      case 'cooldown':
        return 'Cooldown';
      case 'rate_limited':
        return 'Rate Limited';
      default:
        return 'Unknown';
    }
  };

  const formatTimeRemaining = (cooldownUntil: string) => {
    const now = new Date();
    const cooldownTime = new Date(cooldownUntil);
    const diffMs = cooldownTime.getTime() - now.getTime();
    
    if (diffMs <= 0) return "Available now";
    
    const diffSeconds = Math.floor(diffMs / 1000);
    const minutes = Math.floor(diffSeconds / 60);
    const seconds = diffSeconds % 60;
    
    if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    }
    return `${seconds}s`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-morphism border-white/20 text-white max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-white">API Key Status</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-8">
              <i className="fas fa-spinner fa-spin text-2xl text-white/50"></i>
              <p className="text-white/70 mt-2">Loading API key status...</p>
            </div>
          ) : (
            <>
              {/* API Key Status List */}
              <div className="space-y-3">
                {apiStatus?.keys?.map((key: any, index: number) => (
                  <Card key={index} className="bg-white/10 border-white/20">
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(key.status)}`}></div>
                          <span className="text-white font-medium">API Key #{index + 1}</span>
                        </div>
                        <div className="text-right">
                          <div className="text-sm text-white/80">{getStatusText(key.status)}</div>
                          <div className="text-xs text-white/50">
                            {key.cooldownUntil 
                              ? `Available in: ${formatTimeRemaining(key.cooldownUntil)}`
                              : key.lastUsed 
                                ? `Last used: ${new Date(key.lastUsed).toLocaleTimeString()}`
                                : 'Never used'
                            }
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              {/* Reset Button */}
              <Button
                onClick={() => resetMutation.mutate()}
                disabled={resetMutation.isPending}
                className="w-full bg-blue-500/20 border border-blue-500/30 text-blue-300 hover:bg-blue-500/30"
              >
                <i className="fas fa-sync-alt mr-2"></i>
                {resetMutation.isPending ? 'Resetting...' : 'Reset All Keys'}
              </Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
