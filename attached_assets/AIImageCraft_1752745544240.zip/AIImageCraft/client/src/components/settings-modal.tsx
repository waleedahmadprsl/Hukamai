import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useTheme } from "@/components/theme-provider";
import { usePromptHistory } from "@/hooks/use-prompt-history";
import { useToast } from "@/hooks/use-toast";

interface SettingsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsModal({ open, onOpenChange }: SettingsModalProps) {
  const [customApiKey, setCustomApiKey] = useState("");
  const [showApiKey, setShowApiKey] = useState(false);
  const { theme, setTheme } = useTheme();
  const { clearHistory } = usePromptHistory();
  const { toast } = useToast();

  useEffect(() => {
    // Load saved API key from localStorage
    const savedApiKey = localStorage.getItem("hukam-custom-api-key");
    if (savedApiKey) {
      setCustomApiKey(savedApiKey);
    }
  }, []);

  const handleSaveApiKey = () => {
    if (customApiKey.trim()) {
      localStorage.setItem("hukam-custom-api-key", customApiKey);
      toast({
        title: "API Key saved",
        description: "Your custom API key has been saved successfully",
      });
    } else {
      localStorage.removeItem("hukam-custom-api-key");
      toast({
        title: "API Key removed",
        description: "Custom API key has been removed",
      });
    }
  };

  const handleClearHistory = () => {
    clearHistory();
    toast({
      title: "History cleared",
      description: "Your prompt history has been cleared",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-morphism border-white/20 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-white">Settings</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* API Key Management */}
          <div className="space-y-3">
            <Label className="text-sm font-medium text-white/80">Custom API Key</Label>
            <div className="flex space-x-2">
              <Input
                type={showApiKey ? "text" : "password"}
                placeholder="Enter your Together AI API key"
                value={customApiKey}
                onChange={(e) => setCustomApiKey(e.target.value)}
                className="flex-1 bg-white/10 border-white/20 text-white placeholder-white/50 focus:border-indigo-400"
              />
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowApiKey(!showApiKey)}
                className="text-white hover:bg-white/20"
              >
                <i className={`fas ${showApiKey ? 'fa-eye-slash' : 'fa-eye'}`}></i>
              </Button>
              <Button
                onClick={handleSaveApiKey}
                className="bg-green-500 hover:bg-green-600 text-white"
              >
                <i className="fas fa-save"></i>
              </Button>
            </div>
            <p className="text-xs text-white/50">Optional: Use your own API key for unlimited generations</p>
          </div>
          
          {/* Theme Settings */}
          <div className="space-y-3">
            <Label className="text-sm font-medium text-white/80">Theme</Label>
            <div className="flex space-x-2">
              <Button
                variant={theme === "light" ? "default" : "outline"}
                onClick={() => setTheme("light")}
                className="flex-1 bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                <i className="fas fa-sun mr-2"></i>
                Light
              </Button>
              <Button
                variant={theme === "dark" ? "default" : "outline"}
                onClick={() => setTheme("dark")}
                className="flex-1 bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                <i className="fas fa-moon mr-2"></i>
                Dark
              </Button>
            </div>
          </div>
          
          {/* Clear History */}
          <div className="space-y-3">
            <Label className="text-sm font-medium text-white/80">Data Management</Label>
            <Button
              onClick={handleClearHistory}
              className="w-full bg-red-500/20 border border-red-500/30 text-red-300 hover:bg-red-500/30"
            >
              <i className="fas fa-trash mr-2"></i>
              Clear Prompt History
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
