import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { usePromptHistory } from "@/hooks/use-prompt-history";
import { useState } from "react";

interface PromptHistoryPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function PromptHistoryPanel({ open, onOpenChange }: PromptHistoryPanelProps) {
  const { history, removePrompt, clearHistory } = usePromptHistory();
  const [searchTerm, setSearchTerm] = useState("");

  const filteredHistory = history.filter(item => 
    item.prompt.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSelectPrompt = (prompt: string) => {
    // Copy to clipboard
    navigator.clipboard.writeText(prompt);
    
    // You could also emit an event or use a callback to set the prompt in the main component
    // For now, we'll just show a toast-like notification
    const event = new CustomEvent('promptSelected', { detail: { prompt } });
    window.dispatchEvent(event);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-morphism border-white/20 text-white max-w-md max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-white">Prompt History</DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 flex flex-col space-y-4">
          {/* Search */}
          <Input
            placeholder="Search prompts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-white/10 border-white/20 text-white placeholder-white/50 focus:border-indigo-400"
          />
          
          {/* History List */}
          <div className="flex-1 overflow-y-auto space-y-3">
            {filteredHistory.length > 0 ? (
              filteredHistory.map((item, index) => (
                <Card 
                  key={index} 
                  className="bg-white/10 border-white/20 hover:bg-white/20 transition-colors cursor-pointer"
                  onClick={() => handleSelectPrompt(item.prompt)}
                >
                  <CardContent className="p-4">
                    <div className="text-sm text-white/80 mb-2">
                      {item.timestamp.toLocaleDateString()} at {item.timestamp.toLocaleTimeString()}
                    </div>
                    <div className="text-white leading-relaxed mb-3">{item.prompt}</div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-white/50">Click to copy</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          removePrompt(index);
                        }}
                        className="text-white/60 hover:text-red-400 hover:bg-red-500/20"
                      >
                        <i className="fas fa-trash"></i>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-8">
                <i className="fas fa-history text-4xl text-white/30 mb-4"></i>
                <p className="text-white/70">
                  {searchTerm ? 'No prompts found' : 'No prompt history yet'}
                </p>
              </div>
            )}
          </div>
          
          {/* Clear Button */}
          {history.length > 0 && (
            <Button
              onClick={clearHistory}
              className="w-full bg-red-500/20 border border-red-500/30 text-red-300 hover:bg-red-500/30"
            >
              <i className="fas fa-trash mr-2"></i>
              Clear All History
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
