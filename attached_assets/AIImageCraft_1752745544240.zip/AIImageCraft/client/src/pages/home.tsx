import { useState } from "react";
import { ImageGenerator } from "@/components/image-generator";
import { SettingsModal } from "@/components/settings-modal";
import { ApiStatusModal } from "@/components/api-status-modal";
import { PromptHistoryPanel } from "@/components/prompt-history-panel";
import { useTheme } from "@/components/theme-provider";

export default function Home() {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [apiStatusOpen, setApiStatusOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };

  return (
    <div className="min-h-screen gradient-bg dark:gradient-bg transition-all duration-300">
      {/* Header */}
      <header className="glass-morphism shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
                <i className="fas fa-magic text-white text-xl"></i>
              </div>
              <h1 className="text-2xl font-bold text-white">Hukam Image Generations</h1>
            </div>
            
            {/* Navigation */}
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#" className="text-white/80 hover:text-white transition-colors">Generate</a>
              <a href="#" className="text-white/80 hover:text-white transition-colors" onClick={() => setHistoryOpen(true)}>History</a>
              <a href="#" className="text-white/80 hover:text-white transition-colors">Gallery</a>
            </nav>
            
            {/* Settings & Theme Toggle */}
            <div className="flex items-center space-x-4">
              <button 
                className="p-2 rounded-lg glass-morphism hover:bg-white/20 transition-colors"
                onClick={toggleTheme}
              >
                <i className={`fas ${theme === 'light' ? 'fa-moon' : 'fa-sun'} text-white`}></i>
              </button>
              <button 
                className="p-2 rounded-lg glass-morphism hover:bg-white/20 transition-colors"
                onClick={() => setSettingsOpen(true)}
              >
                <i className="fas fa-cog text-white"></i>
              </button>
              <button 
                className="p-2 rounded-lg glass-morphism hover:bg-white/20 transition-colors"
                onClick={() => setApiStatusOpen(true)}
              >
                <i className="fas fa-key text-white"></i>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ImageGenerator />
      </main>

      {/* Modals and Panels */}
      <SettingsModal open={settingsOpen} onOpenChange={setSettingsOpen} />
      <ApiStatusModal open={apiStatusOpen} onOpenChange={setApiStatusOpen} />
      <PromptHistoryPanel open={historyOpen} onOpenChange={setHistoryOpen} />

      {/* Floating History Button */}
      <button 
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-full shadow-2xl hover:from-indigo-600 hover:to-purple-700 transition-all duration-300 hover-glow z-30"
        onClick={() => setHistoryOpen(true)}
      >
        <i className="fas fa-history"></i>
      </button>
    </div>
  );
}
