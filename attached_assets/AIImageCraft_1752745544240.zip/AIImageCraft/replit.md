# Hukam Image Generations

## Overview

This is a full-stack AI image generation web application built with React (frontend) and Node.js/Express (backend). The application uses Together AI's Flux model to generate images from text prompts, featuring a modern glassmorphism design with multi-API key rotation for reliability.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

**2025-01-13**: Major batch processing and UI improvements
- Fixed batch prompt generation to process prompts sequentially instead of single-click generation
- Implemented proper per-prompt image count logic (1-10 images per prompt)
- Added stop generation functionality with red stop button
- Enhanced progress tracking with live image preview and shimmer loading effects
- Increased API timeout from 30s to 60s for better reliability
- Added visual feedback for current image generation status
- Fixed image generation flow to create images one-by-one with proper 20-second delays
- Added prompt counter showing detected prompts and total images to be generated
- Migrated from in-memory storage to PostgreSQL database for persistent image storage

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and building
- **Styling**: Tailwind CSS with custom glassmorphism design
- **UI Components**: Radix UI primitives with shadcn/ui components
- **State Management**: React Query (@tanstack/react-query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Theme**: Dark mode support with custom theme provider

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript
- **API Design**: RESTful endpoints under `/api/*`
- **Database**: PostgreSQL with Drizzle ORM
- **Session Storage**: PostgreSQL database for persistent storage
- **CORS**: Enabled for cross-origin requests
- **File Serving**: Vite dev server in development, static files in production

### Key Components

#### API Key Management
- **Multi-key rotation**: 4 Together AI API keys with round-robin selection
- **Failover logic**: Automatic key switching on failures
- **Cooldown system**: Prevents overuse of rate-limited keys
- **Status monitoring**: Real-time API key health tracking

#### Image Generation Service
- **Model**: Together AI's `black-forest-labs/FLUX.1-schnell-Free`
- **Parameters**: 768x768 resolution, 4 steps, 1-10 images per request
- **Rate limiting**: 20-second delays between prompts
- **Retry logic**: 60-second wait for rate-limited requests

#### Image Processing
- **Proxy endpoint**: `/api/proxy-image` bypasses CORS for image downloads
- **ZIP creation**: JSZip for bulk image downloads
- **Filename generation**: Sanitized prompt-based naming

#### UI Features
- **Prompt templates**: Pre-built templates for common use cases
- **Surprise me**: Random prompt generation
- **History tracking**: LocalStorage-based prompt history
- **Progress tracking**: Real-time generation progress with countdown
- **Bulk generation**: Support for up to 500 prompts
- **Download options**: Individual images or ZIP archive

## Data Flow

1. **User Input**: User enters prompt and selects generation parameters
2. **API Request**: Frontend sends POST to `/api/generate-image`
3. **Key Selection**: Backend selects available API key using round-robin
4. **Image Generation**: Together AI API call with retry logic
5. **Response Processing**: Generated image URLs returned to frontend
6. **Display**: Images displayed in responsive grid/list view
7. **Download**: Images fetched via proxy endpoint for ZIP creation

## External Dependencies

### Production Dependencies
- **@neondatabase/serverless**: PostgreSQL database driver
- **@radix-ui/***: UI component primitives
- **@tanstack/react-query**: Server state management
- **axios**: HTTP client for API requests
- **drizzle-orm**: Database ORM
- **express**: Web framework
- **jszip**: ZIP file creation
- **file-saver**: File download utility
- **tailwindcss**: Utility-first CSS framework

### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Type checking
- **tsx**: TypeScript execution
- **drizzle-kit**: Database migrations
- **eslint**: Code linting
- **postcss**: CSS processing

## Deployment Strategy

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `TOGETHER_AI_KEY_1` through `TOGETHER_AI_KEY_4`: Together AI API keys
- `NODE_ENV`: Environment mode (development/production)

### Build Process
1. **Frontend**: Vite builds React app to `dist/public`
2. **Backend**: esbuild bundles Express server to `dist/index.js`
3. **Database**: Drizzle migrations applied via `db:push`

### Deployment Configuration
- **Development**: `npm run dev` - runs tsx with hot reload
- **Production**: `npm run build && npm start` - builds and serves static files
- **Database**: PostgreSQL (configured for Neon DB)

### File Structure
```
├── client/          # React frontend
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── hooks/       # Custom hooks
│   │   ├── lib/         # Utilities
│   │   └── pages/       # Route components
├── server/          # Express backend
│   ├── routes.ts    # API endpoints
│   ├── services/    # Business logic
│   └── storage.ts   # Data persistence
├── shared/          # Shared schemas and types
└── migrations/      # Database migrations
```

### Security Considerations
- API keys stored as environment variables
- CORS configured for development
- Input validation using Zod schemas
- Rate limiting through API key rotation
- No authentication system (as per requirements)