import { generatedImages, type GeneratedImage, type InsertGeneratedImage } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Image generation history
  saveGeneratedImage(image: InsertGeneratedImage): Promise<GeneratedImage>;
  getGeneratedImages(): Promise<GeneratedImage[]>;
  
  // API key management
  getApiKeyStatus(): Promise<any>;
  updateApiKeyStatus(status: any): Promise<void>;
  resetApiKeys(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async saveGeneratedImage(insertImage: InsertGeneratedImage): Promise<GeneratedImage> {
    const [image] = await db
      .insert(generatedImages)
      .values({
        ...insertImage,
        apiKeyUsed: insertImage.apiKeyUsed || null,
      })
      .returning();
    return image;
  }

  async getGeneratedImages(): Promise<GeneratedImage[]> {
    const images = await db
      .select()
      .from(generatedImages)
      .orderBy(desc(generatedImages.createdAt))
      .limit(100); // Limit to latest 100 images
    return images;
  }

  async getApiKeyStatus(): Promise<any> {
    // API key status is handled by the TogetherAI service, not stored in DB
    return {
      keys: [
        { keyIndex: 0, status: 'active', lastUsed: null, cooldownUntil: null, failureCount: 0 },
        { keyIndex: 1, status: 'active', lastUsed: null, cooldownUntil: null, failureCount: 0 },
        { keyIndex: 2, status: 'active', lastUsed: null, cooldownUntil: null, failureCount: 0 },
        { keyIndex: 3, status: 'active', lastUsed: null, cooldownUntil: null, failureCount: 0 },
      ],
      currentKeyIndex: 0,
    };
  }

  async updateApiKeyStatus(status: any): Promise<void> {
    // API key status is handled by the TogetherAI service, not stored in DB
    // This method is kept for interface compatibility
  }

  async resetApiKeys(): Promise<void> {
    // API key status is handled by the TogetherAI service, not stored in DB
    // This method is kept for interface compatibility
  }
}

export const storage = new DatabaseStorage();
