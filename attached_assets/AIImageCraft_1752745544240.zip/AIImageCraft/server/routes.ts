import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { togetherAI } from "./services/together-ai";
import { generateImageRequestSchema, generateImageResponseSchema } from "@shared/schema";
import axios from "axios";
import cors from "cors";

export async function registerRoutes(app: Express): Promise<Server> {
  // Enable CORS for all routes
  app.use(cors({
    origin: true,
    credentials: true,
  }));

  // Image generation endpoint
  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt, n = 1, customApiKey } = generateImageRequestSchema.parse(req.body);
      
      const result = await togetherAI.generateImage(prompt, n, customApiKey);
      
      // Save to storage
      for (const image of result.images) {
        await storage.saveGeneratedImage({
          prompt: image.prompt,
          imageUrl: image.url,
          apiKeyUsed: result.usedApiKey,
        });
      }
      
      res.json(result);
    } catch (error: any) {
      console.error('Image generation error:', error);
      res.status(500).json({ 
        error: error.message || 'Failed to generate image'
      });
    }
  });

  // Get API key status
  app.get("/api/api-key-status", async (req, res) => {
    try {
      const status = togetherAI.getKeyStatus();
      res.json(status);
    } catch (error: any) {
      console.error('API key status error:', error);
      res.status(500).json({ 
        error: 'Failed to get API key status'
      });
    }
  });

  // Reset API keys
  app.post("/api/reset-api-keys", async (req, res) => {
    try {
      togetherAI.resetAllKeys();
      await storage.resetApiKeys();
      res.json({ message: 'API keys reset successfully' });
    } catch (error: any) {
      console.error('Reset API keys error:', error);
      res.status(500).json({ 
        error: 'Failed to reset API keys'
      });
    }
  });

  // Proxy endpoint for fetching images (CORS bypass)
  app.get("/api/proxy-image", async (req, res) => {
    try {
      const { url } = req.query;
      
      if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: 'URL parameter is required' });
      }

      const response = await axios.get(url, {
        responseType: 'stream',
        timeout: 30000,
      });

      // Set appropriate headers
      res.setHeader('Content-Type', response.headers['content-type'] || 'image/png');
      res.setHeader('Content-Length', response.headers['content-length'] || '0');
      
      // Pipe the image data
      response.data.pipe(res);
    } catch (error: any) {
      console.error('Proxy image error:', error);
      res.status(500).json({ 
        error: 'Failed to fetch image'
      });
    }
  });

  // Get generated images
  app.get("/api/images", async (req, res) => {
    try {
      const images = await storage.getGeneratedImages();
      res.json(images);
    } catch (error: any) {
      console.error('Get images error:', error);
      res.status(500).json({ 
        error: 'Failed to get images'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
