import axios, { AxiosResponse } from 'axios';

interface TogetherAIRequest {
  model: string;
  prompt: string;
  width: number;
  height: number;
  steps: number;
  n: number;
}

interface TogetherAIResponse {
  data: Array<{
    url: string;
  }>;
}

export class TogetherAIService {
  private readonly apiKeys: string[] = [
    process.env.TOGETHER_AI_KEY_1 || '30007227e495131a87c70d558f56cd54d212c47ab94221f2299e11da832b3166',
    process.env.TOGETHER_AI_KEY_2 || '34b44ff37f5f56048ae0475f4acafc05bb8a252c23a2c5797300e166aa5b31d9',
    process.env.TOGETHER_AI_KEY_3 || '1d4fb6b33893281cb45c2107ebf4a49744497902500e23a35ef63837d93dcac3',
    process.env.TOGETHER_AI_KEY_4 || 'dadc74fda1176aa1ab68c129b7cf9805e2f5b3e82fc7c81124db24214133d8f6',
  ];

  private keyStatus: Array<{
    keyIndex: number;
    status: 'active' | 'cooldown' | 'rate_limited';
    lastUsed?: Date;
    cooldownUntil?: Date;
    failureCount: number;
  }> = [];

  private currentKeyIndex = 0;

  constructor() {
    this.initializeKeyStatus();
  }

  private initializeKeyStatus() {
    this.keyStatus = this.apiKeys.map((_, index) => ({
      keyIndex: index,
      status: 'active' as const,
      failureCount: 0,
    }));
  }

  private getNextAvailableKey(): { key: string; index: number } | null {
    const now = new Date();
    
    // Check each key starting from current index
    for (let i = 0; i < this.apiKeys.length; i++) {
      const keyIndex = (this.currentKeyIndex + i) % this.apiKeys.length;
      const keyStatus = this.keyStatus[keyIndex];
      
      // Skip if in cooldown
      if (keyStatus.cooldownUntil && now < keyStatus.cooldownUntil) {
        continue;
      }
      
      // Reset status if cooldown has expired
      if (keyStatus.cooldownUntil && now >= keyStatus.cooldownUntil) {
        keyStatus.status = 'active';
        keyStatus.cooldownUntil = undefined;
        keyStatus.failureCount = 0;
      }
      
      // Use this key if available
      if (keyStatus.status === 'active' || keyStatus.status === 'rate_limited') {
        this.currentKeyIndex = (keyIndex + 1) % this.apiKeys.length;
        return { key: this.apiKeys[keyIndex], index: keyIndex };
      }
    }
    
    return null;
  }

  private handleKeyFailure(keyIndex: number, error: any) {
    const keyStatus = this.keyStatus[keyIndex];
    keyStatus.failureCount++;
    
    if (error.response?.status === 429) {
      // Rate limited - cooldown for 60 seconds
      keyStatus.status = 'cooldown';
      keyStatus.cooldownUntil = new Date(Date.now() + 60 * 1000);
    } else if (keyStatus.failureCount >= 3) {
      // Too many failures - longer cooldown
      keyStatus.status = 'cooldown';
      keyStatus.cooldownUntil = new Date(Date.now() + 5 * 60 * 1000);
    }
  }

  async generateImage(prompt: string, n: number = 1, customApiKey?: string): Promise<{
    images: Array<{ url: string; prompt: string }>;
    usedApiKey: string;
  }> {
    const apiKey = customApiKey || this.getNextAvailableKey()?.key;
    
    if (!apiKey) {
      throw new Error('No available API keys. All keys are in cooldown.');
    }

    const keyIndex = customApiKey ? -1 : this.keyStatus.findIndex(k => 
      this.apiKeys[k.keyIndex] === apiKey
    );

    const requestData: TogetherAIRequest = {
      model: 'black-forest-labs/FLUX.1-schnell-Free',
      prompt,
      width: 768,
      height: 768,
      steps: 4, // Important: Max 4 steps for this model
      n: Math.min(n, 10), // Max 10 images
    };

    try {
      const response: AxiosResponse<TogetherAIResponse> = await axios.post(
        'https://api.together.xyz/v1/images/generations',
        requestData,
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
          },
          timeout: 60000, // 60 second timeout
        }
      );

      // Update success status
      if (keyIndex >= 0) {
        this.keyStatus[keyIndex].lastUsed = new Date();
        this.keyStatus[keyIndex].status = 'active';
        this.keyStatus[keyIndex].failureCount = 0;
      }

      return {
        images: response.data.data.map(img => ({
          url: img.url,
          prompt,
        })),
        usedApiKey: `API Key #${keyIndex + 1}`,
      };
    } catch (error: any) {
      if (keyIndex >= 0) {
        this.handleKeyFailure(keyIndex, error);
      }
      
      if (error.response?.status === 429) {
        throw new Error('Rate limit exceeded. Please wait before trying again.');
      }
      
      throw new Error(`Image generation failed: ${error.message}`);
    }
  }

  getKeyStatus() {
    return {
      keys: this.keyStatus.map(status => ({
        ...status,
        isAvailable: status.status === 'active' && (!status.cooldownUntil || new Date() >= status.cooldownUntil),
      })),
      currentKeyIndex: this.currentKeyIndex,
    };
  }

  resetAllKeys() {
    this.initializeKeyStatus();
  }
}

export const togetherAI = new TogetherAIService();
