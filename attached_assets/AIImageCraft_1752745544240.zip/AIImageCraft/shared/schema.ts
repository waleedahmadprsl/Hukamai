import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const generatedImages = pgTable("generated_images", {
  id: serial("id").primaryKey(),
  prompt: text("prompt").notNull(),
  imageUrl: text("image_url").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  apiKeyUsed: text("api_key_used"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertGeneratedImageSchema = createInsertSchema(generatedImages).pick({
  prompt: true,
  imageUrl: true,
  apiKeyUsed: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type GeneratedImage = typeof generatedImages.$inferSelect;
export type InsertGeneratedImage = z.infer<typeof insertGeneratedImageSchema>;

// API request/response schemas
export const generateImageRequestSchema = z.object({
  prompt: z.string().min(1),
  n: z.number().min(1).max(10).default(1),
  customApiKey: z.string().optional(),
});

export const generateImageResponseSchema = z.object({
  images: z.array(z.object({
    url: z.string(),
    prompt: z.string(),
  })),
  usedApiKey: z.string(),
});

export const apiKeyStatusSchema = z.object({
  keyIndex: z.number(),
  status: z.enum(['active', 'cooldown', 'rate_limited']),
  lastUsed: z.date().optional(),
  cooldownUntil: z.date().optional(),
  failureCount: z.number().default(0),
});

export type GenerateImageRequest = z.infer<typeof generateImageRequestSchema>;
export type GenerateImageResponse = z.infer<typeof generateImageResponseSchema>;
export type ApiKeyStatus = z.infer<typeof apiKeyStatusSchema>;
